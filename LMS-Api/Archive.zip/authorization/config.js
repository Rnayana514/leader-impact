module.exports = {
	JWT_SECRET : 'my secret key'
}
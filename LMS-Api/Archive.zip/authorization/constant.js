module.exports = {
	DIR: 'https://kakinadaindia.com/uploads/events',
	blogsDir: 'https://kakinadaindia.com/uploads/blogs',
	profileDir: 'https://kakinadaindia.com/uploads/profile',
	eventsDir: 'https://kakinadaindia.com/uploads/events',
	redirectlink: 'https://kakinadaindia.com/register/',
	forgotredirectlink: 'https://kakinadaindia.com/forgot-password/',
	info_email: 'reubenjathanna1991@gmail.com',
	info_password: 'dmjvrdljykxjwmkz'//'reuben@951991'  http://localhost:4200/home
}

